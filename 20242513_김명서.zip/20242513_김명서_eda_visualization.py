import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from urllib.parse import unquote
import os
import re

# ============================================================
# 페이지 설정
# ============================================================
st.set_page_config(
    page_title="CSIC 2010 웹 공격 EDA",
    page_icon="🔍",
    layout="wide"
)

st.title("🔍 CSIC 2010 웹 공격 데이터 탐색적 분석")
st.markdown("**HTTP 요청 텍스트에서 공격 패턴을 찾아봅시다!**")


# ============================================================
# 데이터 로드 및 전처리
# ============================================================
@st.cache_data
def load_data():

    # CSV 파일 경로
    data_path = os.path.join(
        os.path.dirname(__file__),
        "csic2010_requests_full.csv"
    )

    # CSV 읽기
    df = pd.read_csv(data_path)

    # 컬럼 없을 경우 대비
    if "body" not in df.columns:
        df["body"] = ""

    if "method" not in df.columns:
        df["method"] = "UNKNOWN"

    if "label" not in df.columns:
        st.error("❌ label 컬럼이 존재하지 않습니다.")
        st.stop()

    if "url" not in df.columns:
        st.error("❌ url 컬럼이 존재하지 않습니다.")
        st.stop()

    # URL 디코딩
    df["url_decoded"] = df["url"].apply(
        lambda x: unquote(str(x), encoding="latin-1")
    )

    # Body 디코딩
    df["body_decoded"] = df["body"].fillna("").apply(
        lambda x: unquote(str(x), encoding="latin-1")
    )

    # 전체 텍스트
    df["full_text"] = (
        df["url_decoded"] + " " + df["body_decoded"]
    )

    # 길이 특성
    df["url_length"] = df["url_decoded"].str.len()

    df["body_length"] = df["body_decoded"].str.len()

    # 공격 여부 라벨
    df["is_attack"] = (
        df["label"]
        .astype(str)
        .str.lower()
        .isin(["anomalous", "attack", "1"])
    ).astype(int)

    return df


# 데이터 로드
df = load_data()

# ============================================================
# 사이드바 정보
# ============================================================
st.sidebar.header("📊 데이터 기본 정보")

st.sidebar.metric(
    "전체 HTTP 요청",
    f"{len(df):,}건"
)

st.sidebar.metric(
    "정상 요청",
    f"{(df['is_attack']==0).sum():,}건"
)

st.sidebar.metric(
    "공격 요청",
    f"{(df['is_attack']==1).sum():,}건"
)

st.sidebar.metric(
    "공격 비율",
    f"{df['is_attack'].mean()*100:.2f}%"
)

# HTTP 메서드 분포
st.sidebar.markdown("---")
st.sidebar.subheader("HTTP 메서드 분포")

method_dist = df["method"].value_counts()

for method, count in method_dist.items():
    st.sidebar.text(f"{method}: {count:,}건")


# ============================================================
# 탭 구성
# ============================================================
tab1, tab2, tab3, tab4 = st.tabs([
    "📊 분포 분석",
    "📏 길이 분석",
    "🔑 공격 키워드",
    "📄 HTTP 요청 뷰어"
])


# ============================================================
# 탭 1: 분포 분석
# ============================================================
with tab1:

    st.header("📊 정상 vs 공격 분포")

    col1, col2 = st.columns(2)

    # 파이 차트
    with col1:

        label_counts = df["is_attack"].value_counts()

        fig = px.pie(
            values=label_counts.values,
            names=["정상", "공격"],
            title="정상 vs 공격 비율",
            hole=0.4
        )

        st.plotly_chart(fig, use_container_width=True)

    # 메서드별 분포
    with col2:

        cross = pd.crosstab(
            df["method"],
            df["is_attack"]
        ).reset_index()

        cross.columns = ["method", "정상", "공격"]

        melted = cross.melt(
            id_vars="method",
            var_name="구분",
            value_name="개수"
        )

        fig = px.bar(
            melted,
            x="method",
            y="개수",
            color="구분",
            barmode="group",
            title="HTTP 메서드별 정상/공격 분포"
        )

        st.plotly_chart(fig, use_container_width=True)

    # 공격 비율 테이블
    st.subheader("📌 메서드별 공격 비율")

    method_attack = df.groupby("method")["is_attack"].agg(
        ["sum", "count"]
    )

    method_attack["attack_ratio"] = (
        method_attack["sum"]
        / method_attack["count"]
        * 100
    )

    method_attack.columns = [
        "공격 건수",
        "전체 건수",
        "공격 비율(%)"
    ]

    st.dataframe(
        method_attack.round(2),
        use_container_width=True
    )


# ============================================================
# 탭 2: 길이 분석
# ============================================================
with tab2:

    st.header("📏 URL / Body 길이 분석")

    col1, col2 = st.columns(2)

    # URL 길이 히스토그램
    with col1:

        fig = px.histogram(
            df,
            x="url_length",
            color="is_attack",
            nbins=100,
            title="URL 길이 분포"
        )

        st.plotly_chart(fig, use_container_width=True)

    # URL 길이 Box Plot
    with col2:

        fig = px.box(
            df,
            x="is_attack",
            y="url_length",
            color="is_attack",
            title="URL 길이 Box Plot"
        )

        st.plotly_chart(fig, use_container_width=True)

    # POST 요청 분석
    post_df = df[df["method"] == "POST"]

    if len(post_df) > 0:

        st.subheader("📌 POST Body 길이 분석")

        col3, col4 = st.columns(2)

        with col3:

            fig = px.histogram(
                post_df,
                x="body_length",
                color="is_attack",
                nbins=80,
                title="POST Body 길이 분포"
            )

            st.plotly_chart(fig, use_container_width=True)

        with col4:

            fig = px.box(
                post_df,
                x="is_attack",
                y="body_length",
                color="is_attack",
                title="POST Body 길이 Box Plot"
            )

            st.plotly_chart(fig, use_container_width=True)

    # 통계 요약
    st.subheader("📊 길이 통계 요약")

    length_stats = df.groupby("is_attack")[
        ["url_length", "body_length"]
    ].agg(["mean", "median", "max"])

    st.dataframe(
        length_stats.round(2),
        use_container_width=True
    )


# ============================================================
# 탭 3: 공격 키워드 분석
# ============================================================
with tab3:

    st.header("🔑 공격 키워드 탐지")

    attack_categories = {

        "SQL Injection": [
            "'", "select", "union", "drop",
            "insert", "delete", "update",
            "or '", "1=1", "--"
        ],

        "XSS": [
            "<script", "alert(", "onerror",
            "<iframe", "<img", "javascript:"
        ],

        "Path Traversal": [
            "../", "..\\", "/etc/passwd"
        ],

        "Command Injection": [
            "; ", "|", "&&",
            "/bin/", "cat ", "rm "
        ]
    }

    results = []

    for category, keywords in attack_categories.items():

        for kw in keywords:

            normal_count = df[df["is_attack"] == 0][
                "full_text"
            ].str.contains(
                re.escape(kw),
                case=False,
                na=False
            ).sum()

            attack_count = df[df["is_attack"] == 1][
                "full_text"
            ].str.contains(
                re.escape(kw),
                case=False,
                na=False
            ).sum()

            results.append({
                "카테고리": category,
                "키워드": kw,
                "정상 발견": normal_count,
                "공격 발견": attack_count
            })

    result_df = pd.DataFrame(results)

    st.dataframe(
        result_df.sort_values(
            "공격 발견",
            ascending=False
        ),
        use_container_width=True
    )

    # Top 키워드
    top_keywords = result_df.nlargest(
        15,
        "공격 발견"
    )

    fig = px.bar(
        top_keywords,
        x="키워드",
        y="공격 발견",
        color="카테고리",
        title="공격에서 가장 많이 발견된 키워드"
    )

    st.plotly_chart(fig, use_container_width=True)


# ============================================================
# 탭 4: HTTP 요청 뷰어
# ============================================================
with tab4:

    st.header("📄 실제 HTTP 요청 확인")

    attack_option = st.selectbox(
        "요청 종류 선택",
        ["정상 요청", "공격 요청"]
    )

    if attack_option == "정상 요청":
        target_df = df[df["is_attack"] == 0]
    else:
        target_df = df[df["is_attack"] == 1]

    idx = st.number_input(
        "요청 번호",
        min_value=0,
        max_value=len(target_df)-1,
        value=0
    )

    row = target_df.iloc[idx]

    st.subheader("📌 요청 정보")

    st.text(f"Method: {row['method']}")
    st.text(f"URL:\n{row['url_decoded']}")

    if row["body_decoded"]:
        st.text(f"Body:\n{row['body_decoded']}")

    st.markdown("---")

    # 키워드 검색
    st.subheader("🔍 키워드 검색")

    search_kw = st.text_input(
        "검색 키워드 입력",
        value="select"
    )

    if search_kw:

        matched = df[
            df["full_text"].str.contains(
                search_kw,
                case=False,
                na=False
            )
        ]

        st.write(
            f"검색 결과: {len(matched):,}건"
        )

        st.dataframe(
            matched[
                ["method", "url", "label"]
            ].head(20),
            use_container_width=True
        )


# ============================================================
# 하단 요약
# ============================================================
st.markdown("---")

st.header("📝 EDA 핵심 발견")

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.success(
        "공격 URL은 평균적으로 더 길다"
    )

with col2:
    st.success(
        "SQL/XSS 키워드가 공격 요청에 집중된다"
    )

with col3:
    st.warning(
        "HTTP 요청 텍스트만으로도 공격 탐지가 가능하다"
    )

with col4:
    st.success(
        "EDA를 통해 머신러닝 특성 추출 가능"
    )